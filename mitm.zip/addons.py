from mitmproxy import http
import json

TARGET = "/v2/account/authenticate/steam"


class TokenGrabber:
    def response(self, flow: http.HTTPFlow):
        if TARGET not in flow.request.pretty_url:
            return
        try:
            data = json.loads(flow.response.text)
            token = data.get("token")
            refresh = data.get("refresh_token")
            print("=" * 50)
            print("[AUTH] token   =", token)
            print("[AUTH] refresh =", refresh)
            print("=" * 50)
        except Exception as e:
            print("[mitm] Error:", e)


addons = [TokenGrabber()]
