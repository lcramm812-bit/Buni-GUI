import asyncio
from mitmproxy.tools.dump import DumpMaster
from mitmproxy import options
from addons import addons as addon_list

LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = 8080


async def run():
    opts = options.Options(listen_host=LISTEN_HOST, listen_port=LISTEN_PORT)
    master = DumpMaster(opts)
    for a in addon_list:
        master.addons.add(a)
    await master.run()


if __name__ == "__main__":
    print(f"[mitm] proxy running on {LISTEN_HOST}:{LISTEN_PORT}  (Ctrl+C to stop)")
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        print("\n[mitm] stopped")
