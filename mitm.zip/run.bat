@echo off
cd /d "%~dp0"
mitmdump -s stash_capture.py
