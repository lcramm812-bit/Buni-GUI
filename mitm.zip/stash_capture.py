from mitmproxy import http
import json, os, base64

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(OUT_DIR, "stash_dump.txt")
AUTH = os.path.join(OUT_DIR, "auth.json")
NAKAMA = "nakamacloud.io"
INTERESTING = ("/v2/storage", "/v2/rpc/", "/v2/account")


def _write(title, text):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write("\n" + "=" * 78 + "\n" + title + "\n" + "-" * 78 + "\n" + text + "\n")
    print("[capture] " + title)


def _save_auth(**kv):
    data = {}
    if os.path.exists(AUTH):
        try:
            data = json.load(open(AUTH, encoding="utf-8"))
        except Exception:
            pass
    data.update({k: v for k, v in kv.items() if v})
    json.dump(data, open(AUTH, "w", encoding="utf-8"), indent=2)
    print("[capture] auth.json ->", ", ".join(k for k, v in kv.items() if v))


class StashCapture:
    def __init__(self):

        print("[capture] running — logging Nakama storage/rpc/account -> stash_dump.txt (append, keeps scanning)")

    def request(self, flow: http.HTTPFlow):
        if NAKAMA not in flow.request.pretty_url:
            return
        auth = flow.request.headers.get("authorization", "")
        if auth.lower().startswith("basic "):
            try:
                decoded = base64.b64decode(auth.split(" ", 1)[1]).decode("utf-8", "ignore")
                server_key = decoded.split(":", 1)[0]  # "<server_key>:"
                if server_key:
                    _save_auth(server_key=server_key)
            except Exception as e:
                print("[capture] server key decode error:", e)

    def response(self, flow: http.HTTPFlow):
        url = flow.request.pretty_url
        if NAKAMA not in url:
            return
        path = flow.request.path
        if not any(k in path for k in INTERESTING):
            return

        # session token + refresh from the authenticate response
        if "authenticate" in path or "session/refresh" in path:
            try:
                data = json.loads(flow.response.text)
                _save_auth(token=data.get("token"), refresh=data.get("refresh_token"))
            except Exception as e:
                print("[capture] token parse error:", e)

        # bearer used on normal calls (fallback token source)
        auth = flow.request.headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            _save_auth(token=auth.split(" ", 1)[1])

        req = flow.request.get_text() or "(empty)"
        res = flow.response.get_text() or "(empty)"
        _write(f"{flow.request.method} {url}  [{flow.response.status_code}]",
               "REQUEST BODY:\n" + req + "\n\nRESPONSE BODY:\n" + res)

        if "/v2/storage" in path and '"objects"' in res and '"value"' in res:
            print("\n" + "*" * 60 + "\n[STASH DATA CAUGHT] " + url + "\n" + "*" * 60 + "\n")


addons = [StashCapture()]
